//
//  Kisiler.swift
//  KisilerUygulamasi
//
//  Created by Adem Han on 21.12.2024.
//

import Foundation

class Kisiler {
    var Kisi_id: Int?
    var Kisi_ad: String?
    var Kisi_tel: String?
    
    init(Kisi_id: Int, Kisi_ad: String, Kisi_tel: String) {
        self.Kisi_id = Kisi_id
        self.Kisi_ad = Kisi_ad
        self.Kisi_tel = Kisi_tel
    }
}
